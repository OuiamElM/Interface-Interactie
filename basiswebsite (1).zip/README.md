# Basiswebsite voor Interface en Interactie
Een mooie basis met mapjes, html, css en js die goed aan elkaar gelinkt zijn.

## dingen om te doen

- Zet GitHub pages aan (bij Settings).
- Plak een link naar je GitHub pages in het About blokje (rechtsboven)
- Maak van je naam in Indeling & Planning excel in Teams een link naar je GitHub repository.

GitHub is gelijk een backup, maar is ook wat picky-er over wat mooie code is:

- Zet je code elke keer als je voortgang hebt geboekt op GitHub (dan heb je een back-up).
- Test je werk op Github (werkt net anders dan op je eigen computer).
- Laat een ander je werk op GitHub testen.

Code is best leuk, zeker als het lukt:

- Stel vragen als je er naar zelf proberen en zoeken niet uitkomt. 
- Wacht daar niet te lang (en we helpen je graag verder).